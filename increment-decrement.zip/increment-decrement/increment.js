let count = 0;
const counterElement = document.getElementById('counter');



function increment() {
    count++;
    if(count==0){
        counterElement.style.color="black";
    }
    else if(count>0)
    {
        counterElement.style.color="green";
    }
    else{
        counterElement.style.color="red";
    }
    counterElement.innerText = count;
}

function decrement(){
    count--;
    if(count==0){
        counterElement.style.color="black";
    }
    else if(count>0)
    {
        counterElement.style.color="green";
    }
    else{
        counterElement.style.color="red";
    }
    counterElement.innerText = count;
 
}
