function display(val) {
    document.getElementById('result').value += val;
}
function solve() {

    let x = document.getElementById('result').value;
    console.log(x);
    let y = eval(x);
    document.getElementById('result').value = y
}


function clearScreen() {
    document.getElementById('result').value = '';
}